import sqlalchemy
from sqlalchemy_serializer import SerializerMixin

from data.db_session import SqlAlchemyBase, orm


class DairyData(SqlAlchemyBase, SerializerMixin):
    __tablename__ = 'usersproducts'

    id = sqlalchemy.Column(sqlalchemy.Integer,
                           primary_key=True, autoincrement=True)
    product_id = sqlalchemy.Column('product_id', sqlalchemy.Integer,
                                   sqlalchemy.ForeignKey('products.id'))
    product = orm.relation("Product")
    user_id = sqlalchemy.Column('user_id', sqlalchemy.Integer,
                                sqlalchemy.ForeignKey('users.id'))
    user = orm.relation("User")
    date = sqlalchemy.Column('date', sqlalchemy.Date)
    count = sqlalchemy.Column('count', sqlalchemy.Integer)
