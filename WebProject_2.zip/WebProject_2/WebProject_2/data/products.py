import sqlalchemy
from sqlalchemy_serializer import SerializerMixin

from data.db_session import SqlAlchemyBase, orm


class Product(SqlAlchemyBase, SerializerMixin):
    __tablename__ = 'products'

    id = sqlalchemy.Column(sqlalchemy.Integer,
                           primary_key=True, autoincrement=True)
    name = sqlalchemy.Column(sqlalchemy.String, unique=True, nullable=False, index=True)
    count_fats = sqlalchemy.Column(sqlalchemy.Integer)
    count_proteins = sqlalchemy.Column(sqlalchemy.Integer)
    count_carbohydrates = sqlalchemy.Column(sqlalchemy.Integer)
    count_calories = sqlalchemy.Column(sqlalchemy.Integer)
