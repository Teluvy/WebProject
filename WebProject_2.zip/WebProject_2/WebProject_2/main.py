import datetime

from flask import Flask, render_template, g
from flask_login import LoginManager, login_user, logout_user, login_required, \
    current_user
from flask_restful import Api
from flask_wtf import FlaskForm
from werkzeug.utils import redirect
from wtforms import PasswordField, SubmitField, BooleanField, SelectField, \
    IntegerField, StringField
from wtforms.fields.html5 import EmailField, DateField
from wtforms.validators import DataRequired, NumberRange, ValidationError
import sqlalchemy

from apis import users_list_resource, users_resource, product_list_resource, \
    product_resource, dairydata_list_resource, dairydata_resource
from data import db_session
from data.products import Product
from data.users import User
from data.dairydata import DairyData
from apis.auth import *

app = Flask(__name__)
api = Api(app)
app.config['SECRET_KEY'] = '2013381'
login_manager = LoginManager()
login_manager.init_app(app)


class LoginForm(FlaskForm):
    email = EmailField('Email', validators=[
        DataRequired(message='Это поле необходимо заполнить')])
    password = PasswordField('Пароль', validators=[
        DataRequired(message='Это поле необходимо заполнить')])
    remember = BooleanField('Запомнить')
    submit = SubmitField('Войти')


class RegisterForm(FlaskForm):
    email = EmailField('Email', validators=[
        DataRequired(message='Это поле необходимо заполнить')])
    password = PasswordField('Пароль', validators=[
        DataRequired(message='Это поле необходимо заполнить')])
    name = StringField('Имя', validators=[
        DataRequired(message='Это поле необходимо заполнить')])
    submit = SubmitField('Зарегистрироваться')


class DairyForm(FlaskForm):
    date_to = DateField('До:', validators=[
        DataRequired(message='Это поле необходимо заполнить')], default=datetime.datetime.now())
    date_from = DateField('От:', validators=[
        DataRequired(message='Это поле необходимо заполнить')], default=datetime.datetime.now())
    submit = SubmitField('Показать')

    def validate_date_to(form, field):
        if field.data < form.date_from.data:
            raise ValidationError(
                "Начальная дата должна быть меньше конечной")


class AddNoteForm(FlaskForm):
    product = SelectField('Продукт', validators=[
        DataRequired(message='Это поле необходимо заполнить')])
    count = IntegerField('Количество, г', validators=[
        DataRequired(message='Это поле необходимо заполнить'),
        NumberRange(min=1, max=1000, message='Выберите число от 1 до 1000')],
                         default=1)
    date = DateField('День', validators=[
        DataRequired(message='Это поле необходимо заполнить')],
                     default=datetime.date.today())
    submit = SubmitField('Добавить')


class AddProductForm(FlaskForm):
    name = StringField('Название', validators=[
        DataRequired(message='Это поле необходимо заполнить')])
    count_fats = IntegerField('Количество жиров, г', validators=[
        NumberRange(min=0, max=1000, message='Выберите число от 0 до 1000')],
                              default=0)
    count_proteins = IntegerField('Количество белков, г', validators=[
        NumberRange(min=0, max=1000, message='Выберите число от 0 до 1000')],
                                  default=0)
    count_carbohydrates = IntegerField('Количество углеводов, г', validators=[
        NumberRange(min=0, max=1000, message='Выберите число от 0 до 1000')],
                                       default=0)
    count_calories = IntegerField('Количество калорий, Ккал', validators=[
        NumberRange(min=1, max=1000, message='Выберите число от 1 до 1000')],
                                  default=1)
    submit = SubmitField('Добавить')


@app.errorhandler(Exception)
def error_handler(error):
    return render_template('error.html', title="Страница ошибки", error=error)


def get_user_from_email(email):
    session = db_session.create_session()
    user = session.query(User).filter(User.email == email).first()
    if user:
        return user


def add_data(data):
    session = db_session.create_session()
    session.add(data)
    session.commit()
    session.close()


@auth.verify_password
def verify_password(email, password):
    session = db_session.create_session()
    user = session.query(User).filter_by(email=email).first()
    if not user or not user.check_password(password):
        return False
    session.close()
    g.current_user = user
    return True


@login_manager.user_loader
def get_user_from_id(user_id):
    session = db_session.create_session()
    user = session.query(User).filter(User.id == user_id).first()
    return user


@app.route('/')
@app.route('/index')
def index():
    return render_template('index.html', title="Главная страница")


@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        user = get_user_from_email(form.email.data)
        if user:
            if user.check_password(form.password.data):
                login_user(user, remember=form.remember.data)
                return redirect("/")
        return render_template('login.html', title='Авторизация',
                               message="Неправильный логин или пароль",
                               form=form)
    return render_template('login.html', title='Авторизация', form=form)


@app.route('/register', methods=['GET', 'POST'])
def register():
    form = RegisterForm()
    if form.validate_on_submit():
        user = get_user_from_email(form.email.data)
        if not user:
            user = User()
            user.email = form.email.data
            user.name = form.name.data
            user.admin = False
            user.set_password(form.password.data)
            add_data(user)
            user = get_user_from_email(form.email.data)
            login_user(user)
            return redirect("/")
        return render_template('register.html', title='Регистрация',
                               message="Email занят",
                               form=form)
    return render_template('register.html', title='Регистрация', form=form)


@app.route('/logout')
def logout():
    logout_user()
    return redirect('/')


@app.route('/dairy', methods=['GET', 'POST'])
@login_required
def dairy():
    form = DairyForm()
    param = {}
    session = db_session.create_session()
    products = session.query(DairyData).filter_by(
        user_id=current_user.id).all()
    if not form.validate_on_submit():
        form.date_to.data = datetime.datetime.now()
        form.date_from.data = datetime.datetime.now()
    if len(products):
        query = session.query(DairyData)
        query = query.filter(
            DairyData.date <= datetime.date(form.date_to.data.year,
                                            form.date_to.data.month,
                                            form.date_to.data.day),
            DairyData.date >= datetime.date(form.date_from.data.year,
                                            form.date_from.data.month,
                                            form.date_from.data.day))
        products = query.filter_by(user_id=current_user.id).order_by(
            sqlalchemy.desc(DairyData.date)).all()
    param["products"] = products
    param["all_proteins"] = 0
    param["all_fats"] = 0
    param["all_carbohydrates"] = 0
    param["all_calories"] = 0
    for product in products:
        param["all_proteins"] += product.product.count_proteins * product.count / 100
        param["all_fats"] += product.product.count_fats * product.count / 100
        param[
            "all_carbohydrates"] += product.product.count_carbohydrates * product.count / 100
        param["all_calories"] += product.product.count_calories * product.count / 100
    return render_template('dairy.html', title="Мой дневник", form=form,
                           **param)


@app.route('/add_note', methods=['GET', 'POST'])
@login_required
def add_note():
    form = AddNoteForm()
    session = db_session.create_session()
    products = session.query(Product).all()
    form.product.choices = [(product.id, product.name) for product in products]
    if form.validate_on_submit():
        data = DairyData()
        data.product_id = form.product.data
        data.date = form.date.data
        data.count = form.count.data
        data.user_id = current_user.id
        add_data(data)
        return redirect("/dairy")
    return render_template('add_note.html', title="Добавление записи",
                           form=form)


@app.route('/add_product', methods=['GET', 'POST'])
@login_required
def add_product():
    form = AddProductForm()
    if form.validate_on_submit():
        session = db_session.create_session()
        product = session.query(Product).filter_by(name=form.name.data).first()
        if not product:
            product = Product()
            product.name = form.name.data
            product.count_fats = form.count_fats.data
            product.count_proteins = form.count_proteins.data
            product.count_carbohydrates = form.count_carbohydrates.data
            product.count_calories = form.count_calories.data
            add_data(product)
            return redirect("/add_note")
        return render_template('add_product.html', title="Добавление записи",
                               message="Название занято", form=form)
    return render_template('add_product.html', title="Добавление записи",
                           form=form)


@app.route('/delete_note/<id>', methods=['GET', 'POST'])
@login_required
def delete_note(id):
    session = db_session.create_session()
    data = session.query(DairyData).filter_by(id=id).first()
    if data.user_id == current_user.id:
        session.delete(data)
        session.commit()
    session.close()
    return redirect("/dairy")


@app.route('/api/documentation')
def documentation():
    return render_template('documentation.html', title="Документация")


def main():
    db_session.global_init("db/db.sqlite")
    api.add_resource(users_list_resource.UsersListResource, '/api/users')
    api.add_resource(users_resource.UsersResource, '/api/users/<int:user_id>')
    api.add_resource(product_list_resource.ProductListResource,
                     '/api/products')
    api.add_resource(product_resource.ProductResource,
                     '/api/products/<int:product_id>')
    api.add_resource(dairydata_list_resource.DairyDataListResource,
                     '/api/dairydata')
    api.add_resource(dairydata_resource.DairyDataResource,
                     '/api/dairydata/<int:dairydata_id>')
    #app.run()

if __name__ == '__main__':
    app.run(port=5000, host='127.0.0.1')
#if __name__ == '__main__':

   # main()
