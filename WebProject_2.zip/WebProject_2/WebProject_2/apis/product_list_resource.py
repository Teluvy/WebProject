from flask import jsonify
from flask_restful import reqparse, Resource, abort
from data.products import Product
from data import db_session


parser = reqparse.RequestParser()
parser.add_argument('name', required=True)
parser.add_argument('count_fats', required=True, type=int)
parser.add_argument('count_proteins', required=True, type=int)
parser.add_argument('count_carbohydrates', required=True, type=int)
parser.add_argument('count_calories', required=True, type=int)


class ProductListResource(Resource):
    def post(self):
        args = parser.parse_args()
        session = db_session.create_session()
        product = session.query(Product).filter_by(name=args['name']).first()
        if product:
            abort(400, message='This name do exist')
        product = Product()
        product.name = args['name']
        product.count_fats = args['count_fats']
        product.count_proteins = args['count_proteins']
        product.count_carbohydrates = args['count_carbohydrates']
        product.count_calories = args['count_calories']
        session.add(product)
        session.commit()
        return jsonify({'success': 'OK'})
