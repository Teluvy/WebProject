import datetime

from flask import jsonify, g
from flask_restful import reqparse, Resource

from apis.auth import auth
from data.dairydata import DairyData
from data import db_session


parser = reqparse.RequestParser()
parser.add_argument('count', type=int, required=True)
parser.add_argument('product_id', type=int, required=True)
parser.add_argument('date', type=int, required=True)


class DairyDataListResource(Resource):
    @auth.login_required
    def post(self):
        args = parser.parse_args()
        session = db_session.create_session()
        dairydata = DairyData()
        dairydata.count = args['count']
        dairydata.product_id = args['product_id']
        dairydata.user_id = g.current_user.id
        dairydata.date = datetime.datetime.strptime(args['date'], '%d%m%Y').date()
        session.add(dairydata)
        session.commit()
        return jsonify({'success': 'OK'})
