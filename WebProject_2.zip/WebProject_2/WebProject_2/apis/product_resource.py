from flask_restful import reqparse, Resource, abort
from flask import jsonify, g

from apis.auth import auth
from data.products import Product
from data import db_session

parser = reqparse.RequestParser()
parser.add_argument('name')
parser.add_argument('count_fats', type=int)
parser.add_argument('count_proteins', type=int)
parser.add_argument('count_carbohydrates', type=int)
parser.add_argument('count_calories', type=int)


class ProductResource(Resource):
    def get(self, product_id):
        session = db_session.create_session()
        product = session.query(Product).filter_by(id=product_id).first()
        if product:
            return jsonify(product.to_dict(only=(
            'id', 'name', 'count_fats', 'count_proteins',
            'count_carbohydrates', 'count_calories')))
        abort(404, message=f"Product {product_id} not found")

    @auth.login_required
    def put(self, product_id):
        user = g.current_user
        if user.admin:
            session = db_session.create_session()
            product = session.query(Product).filter_by(id=product_id).first()
            if not product:
                abort(404, message=f"Product {product_id} not found")
            args = parser.parse_args()
            if args['name']:
                product.name = args['name']
            if args['count_fats']:
                product.count_fats = args['count_fats']
            if args['count_proteins']:
                product.count_proteins = args['count_proteins']
            if args['count_carbohydrates']:
                product.count_carbohydrates = args['count_carbohydrates']
            if args['count_calories']:
                product.count_calories = args['count_calories']
            session.add(product)
            session.commit()
            return jsonify({'success': 'OK'})
        abort(403, error="Forbidden")

    @auth.login_required
    def delete(self, product_id):
        user = g.current_user
        if user.admin:
            session = db_session.create_session()
            product = session.query(Product).filter_by(id=product_id).first()
            if not product:
                abort(404, message=f"Product {product_id} not found")
            session.delete(product)
            session.commit()
            return jsonify({'success': 'OK'})
        abort(403, error="Forbidden")
