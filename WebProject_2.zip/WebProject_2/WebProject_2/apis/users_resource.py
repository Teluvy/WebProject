from flask_restful import reqparse, Resource, abort
from flask import jsonify, g

from apis.auth import auth
from data.users import User
from data import db_session


parser = reqparse.RequestParser()
parser.add_argument('email')
parser.add_argument('password')
parser.add_argument('name')


class UsersResource(Resource):
    def get(self, user_id):
        session = db_session.create_session()
        user = session.query(User).get(user_id)
        if user:
            return jsonify(user.to_dict(only=('id', 'email', 'name')))
        abort(404, message=f"User {user_id} not found")

    @auth.login_required
    def put(self, user_id):
        session = db_session.create_session()
        user = g.current_user
        if user.id == user_id:
            args = parser.parse_args()
            if args['email']:
                user.email = args['email']
            if args['name']:
                user.name = args['name']
            if args['password']:
                user.set_password(args['password'])
            session.add(user)
            session.commit()
            return jsonify({'success': 'OK'})
        abort(403, error="Forbidden")

    @auth.login_required
    def delete(self, user_id):
        session = db_session.create_session()
        user = g.current_user
        if user.id == user_id:
            session.delete(user)
            session.commit()
            return jsonify({'success': 'OK'})
        abort(403, error="Forbidden")
