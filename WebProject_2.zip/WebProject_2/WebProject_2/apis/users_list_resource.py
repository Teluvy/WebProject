from flask import jsonify
from flask_restful import reqparse, Resource, abort
from data.users import User
from data import db_session


parser = reqparse.RequestParser()
parser.add_argument('email', required=True)
parser.add_argument('password', required=True)
parser.add_argument('name', required=True)


class UsersListResource(Resource):
    def post(self):
        args = parser.parse_args()
        session = db_session.create_session()
        user = session.query(User).filter(User.email == args['email']).first()
        if user:
            abort(400, message='This email do exist')
        user = User()
        user.admin = False
        user.email = args['email']
        user.name = args['name']
        user.set_password(args['password'])
        session.add(user)
        session.commit()
        return jsonify({'success': 'OK'})
