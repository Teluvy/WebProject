import datetime

from flask_restful import reqparse, Resource, abort
from flask import jsonify, g
from data.dairydata import DairyData
from data.products import Product
from data.users import User
from data import db_session
from apis.auth import auth

parser = reqparse.RequestParser()
parser.add_argument('name')
parser.add_argument('product_id', type=int)
parser.add_argument('date', type=int)


class DairyDataResource(Resource):
    def get(self, dairydata_id):
        session = db_session.create_session()
        dairydata = session.query(DairyData, User,
                                  Product).filter(DairyData.id == dairydata_id,
                                                  User.id == DairyData.user_id,
                                                  Product.id == DairyData.product_id).first()
        if dairydata:
            return jsonify(
                {
                    'dairydata': dairydata[0].to_dict(
                        only=('id', 'date', 'count')),
                    'user': dairydata[1].to_dict(only=('id', 'email', 'name')),
                    'product': dairydata[2].to_dict(only=(
                    'id', 'name', 'count_fats', 'count_proteins',
                    'count_carbohydrates', 'count_calories'))
                }
            )
        abort(404, message=f"DairyData {dairydata_id} not found")

    @auth.login_required
    def put(self, dairydata_id):
        user = g.current_user
        session = db_session.create_session()
        dairydata = session.query(DairyData).filter_by(id=dairydata_id).first()
        if not dairydata:
            abort(404, message=f"DairyData {dairydata_id} not found")
        if dairydata.user_id == user.id:
            args = parser.parse_args()
            if args['name']:
                dairydata.name = args['name']
            if args['product_id']:
                dairydata.product_id = args['product_id']
            if args['date']:
                dairydata.date = datetime.datetime.strptime(args['date'],
                                                            '%d%m%Y').date()
            session.add(dairydata)
            session.commit()
            return jsonify({'success': 'OK'})
        abort(403, error="Forbidden")

    @auth.login_required
    def delete(self, dairydata_id):
        user = g.current_user
        session = db_session.create_session()
        dairydata = session.query(DairyData).filter_by(id=dairydata_id).first()
        if not dairydata:
            abort(404, message=f"DairyData {dairydata_id} not found")
        if dairydata.user_id == user.id:
            session.delete(dairydata)
            session.commit()
            return jsonify({'success': 'OK'})
        abort(403, error="Forbidden")
