from flask_httpauth import HTTPBasicAuth

auth = HTTPBasicAuth()
